O arquivo integrantes.txt contém os nomes dos integrantes do trabalho.
O código fonte do trabalho está no arquivo lab1.py.
As duas saídas referentes ao exercício 1 e 2, estão nos arquivos saida1.txt e saida2.txt, respectivamente.
